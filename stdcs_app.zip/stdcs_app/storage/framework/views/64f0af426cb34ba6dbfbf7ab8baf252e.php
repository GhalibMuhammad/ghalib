<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            margin: 0;
            font-family: 'Arial', sans-serif;
        }

        #sidebar {
            height: 100%;
            width: 250px;
            position: fixed;
            top: 0;
            left: -250px;
            background-color: white;
            padding-top: 20px;
            transition: 0.5s;
        }

        #sidebar a {
            padding: 10px 15px;
            text-decoration: none;
            font-size: 18px;
            color: black;
            display: block;
            transition: 0.3s;
        }

        #sidebar a:hover {
            background-color: #007BFF;
            color: white;
        }

        #toggle-btn {
            position: fixed;
            left: 10px;
            top: 10px;
            cursor: pointer;
            font-size: 20px;
        }

        .dropdown-content {
            display: none;
            padding-left: 20px;
        }

        .dropdown-content a {
            padding: 8px 15px;
            text-decoration: none;
            font-size: 16px;
            color: black;
            display: block;
            transition: 0.3s;
        }

        .dropdown-content a:hover {
            background-color: #007BFF;
            color: white;
        }
    </style>
</head>

<body>

    <div id="sidebar">
        <a href="#">Dashboard</a>
        <div class="dropdown">
            <a href="#">Data User</a>
            <div class="dropdown-content">
                <a href="#">Data Staff</a>
                <a href="#">Data Guru</a>
            </div>
        </div>
        <div class="dropdown">
            <a href="#">Data Surat</a>
            <div class="dropdown-content">
                <a href="#">Data Klasifikasi</a>
                <a href="#">Data Surat</a>
            </div>
        </div>
    </div>

    <div id="toggle-btn">&#9776; Toggle Sidebar</div>

    <script>
        document.getElementById('toggle-btn').addEventListener('click', function() {
            var sidebar = document.getElementById('sidebar');
            if (sidebar.style.left === '-250px') {
                sidebar.style.left = '0';
            } else {
                sidebar.style.left = '-250px';
            }
        });
    </script>

</body>

</html>
<?php /**PATH C:\xampp2\htdocs\stdcs_app\resources\views/layouts/template.blade.php ENDPATH**/ ?>